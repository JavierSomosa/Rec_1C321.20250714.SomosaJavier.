/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestionDeTransporte;

/**
 *
 * @author Javier
 */
public class ColectivoPasajeros extends Vehiculo{
    private int cantidadDePasajeros;

    public ColectivoPasajeros(int cantidadDePasajeros, String patente, String marca, int anioFabricacion) {
        super(patente, marca, anioFabricacion);
        this.cantidadDePasajeros = cantidadDePasajeros;
    }
    
    @Override
    public void iniciarRecorrido(){
        System.out.println(patente + " Inicio recorrido con " + cantidadDePasajeros + " pasajeros");
    }

    public int getCantidadDePasajeros() {
        return cantidadDePasajeros;
    }

    @Override
    public String toString() {
        return super.toString() + " , Tipo Colectivo, Pasajeros: " + cantidadDePasajeros;
    }
    
    
}
