/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestionDeTransporte;

/**
 *
 * @author Javier
 */
public abstract class Vehiculo implements Comparable<Vehiculo> {
    protected String patente;
    protected String marca;
    protected int anioFabricacion;

    public Vehiculo(String patente, String marca, int anioFabricacion) {
        this.patente = patente;
        this.marca = marca;
        this.anioFabricacion = anioFabricacion;
    }

    public String getPatente() {
        return patente;
    }

    public String getMarca() {
        return marca;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }
    
    public abstract void iniciarRecorrido();
    
    @Override
    public boolean equals(Object obj) {
        if(this == obj) return true;
        if(!(obj instanceof Vehiculo)) return false;
        Vehiculo otro = (Vehiculo) obj;
        return this.patente.equalsIgnoreCase(otro.patente) && this.anioFabricacion == otro.anioFabricacion;
    }

    @Override
    public int compareTo(Vehiculo otro){
        return otro.anioFabricacion - this.anioFabricacion;
    }

    @Override
    public String toString() {
        return "Vehiculo{" + "patente=" + patente + ", marca=" + marca + ", anioFabricacion=" + anioFabricacion + '}';
    }
    
    
    
}
