/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package GestionDeTransporte;

import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        EmpresaDeLogistica empresa = new EmpresaDeLogistica();
        Scanner sc = new Scanner(System.in);
    
    
    while (true) {
            System.out.println("'\n1. Agregar Vehiculo");
            System.out.println("'\n2. Mostrar todos los vehiculos");
            System.out.println("'\n3. Iniciar recorrido de transporte");
            System.out.println("'\n4. Mostrar vehiculos ordenados por marca");
            System.out.println("'\n5. Mostrar vehiculos ordenados por año de fabricacion");
            System.out.println("'\n6. Mostrar vehiculos ordenados por capacidad");
            System.out.println("'\n7. Salir");
            System.out.print("Seleccione una opcion: ");
            
            String opcion = sc.nextLine();
            
            switch(opcion){
                case "1":
                    System.out.println("Elije el tipo de vehiculo del 1 al 3 (1: Camion, 2: colectivo, 3: Inspeccion)");
                    int tipo = Integer.parseInt(sc.nextLine());
                    System.out.println("Patente: ");
                    String patente = sc.nextLine();
                    System.out.println("Marca: ");
                    String marca =  sc.nextLine();
                    System.out.println("Año de fabricacion");
                    int anio = Integer.parseInt(sc.nextLine());
                    
                    if (tipo == 1){
                        System.out.println("Capacidad de carga de 1 a 30");
                        int carga = Integer.parseInt(sc.nextLine());
                        empresa.agregarVehiculo(new CamionCarga(carga, patente, marca, anio));
                    }else if(tipo == 2){
                        System.out.println("Cantidad de pasajeros: ");
                        int pasajeros = Integer.parseInt(sc.nextLine());
                        empresa.agregarVehiculo(new ColectivoPasajeros(pasajeros, patente, marca, anio));
                    }
                    else if(tipo == 3){
                        System.out.println("Uso asignado (MANTENIMIENTO / SUPERVISIÓN / EMERGENCIA )");
                        UsoAsignado uso = UsoAsignado.valueOf(sc.nextLine().toUpperCase());
                        empresa.agregarVehiculo(new VehiculoDeInspeccion(uso, patente, marca, anio));
                    }else{
                        System.out.println("Tipo invalido.");
                    }
                    break;
                    
                case "2":
                    empresa.mostrarVehiculos();
                    break;
                case "3":
                    empresa.iniciarRecorrido();
                case "4":
                    empresa.ordenarPorMarcas();
                    break;
                case "5":
                    empresa.ordenarPorAnio();
                    break;
                case "6":
                    empresa.oredenarPorCapacidad();
                    break;
                case "7":
                    System.out.println("Saliendo");
                    return;
                default:
                    System.out.println("Opcion invalida");
            }
        }
    }
}
