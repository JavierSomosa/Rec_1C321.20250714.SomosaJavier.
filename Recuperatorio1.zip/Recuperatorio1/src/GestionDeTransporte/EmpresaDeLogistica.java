/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestionDeTransporte;

import java.util.*;

/**
 *
 * @author Javier
 */
public class EmpresaDeLogistica {
    private List<Vehiculo> vehiculos;

    public EmpresaDeLogistica() {
        this.vehiculos = new ArrayList<>();
    }
    
    public boolean agregarVehiculo(Vehiculo v){
        if(vehiculos.contains(v)){
            System.out.println("Ya existe un vehiculo con esta misma patente y año");
            return false;
        }
        vehiculos.add(v);
        System.out.println("Vehiculo agregado");
        return true;
    }
    
    public void mostrarVehiculos(){
        if(vehiculos.isEmpty()){
            System.out.println("No hay vehiculos");
        }else{
            vehiculos.forEach(System.out::println);
        }
    }
    
    public void iniciarRecorrido(){
        for (Vehiculo v: vehiculos){
            v.iniciarRecorrido();
        }
    }
    
    public void ordenarPorMarcas(){
        Collections.sort(vehiculos);
        mostrarVehiculos();
    }
    
    public void ordenarPorAnio() {
        Collections.sort(vehiculos);
        mostrarVehiculos();
    }
    
    public void oredenarPorCapacidad(){
        vehiculos.sort((v1, v2) -> {
        int c1 = 0, c2 = 0;
        if (v1 instanceof CamionCarga camionCarga) c1 = camionCarga.getCapacidadDeCarga();
        else if (v1 instanceof ColectivoPasajeros) c1 = ((ColectivoPasajeros) v1).getCantidadDePasajeros();
        if (v2 instanceof CamionCarga) c2 = ((CamionCarga) v2).getCapacidadDeCarga();
        else if (v2 instanceof ColectivoPasajeros) c2 = ((ColectivoPasajeros) v2).getCantidadDePasajeros();
        return Integer.compare(c2, c1);
    });
        mostrarVehiculos();
    }
}
