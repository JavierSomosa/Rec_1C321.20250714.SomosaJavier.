/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestionDeTransporte;

/**
 *
 * @author Javier
 */
public class CamionCarga extends Vehiculo{
    private int capacidadCarga;

    public CamionCarga(int capacidadCarga, String patente, String marca, int anioFabricacion) {
        super(patente, marca, anioFabricacion);
        if (capacidadCarga < 1){
            capacidadCarga = 1;
        }
        if(capacidadCarga > 30){
            capacidadCarga = 30;
        }
        this.capacidadCarga = capacidadCarga;
    }
    
    @Override
    public void iniciarRecorrido(){
        System.out.println(patente + " Inicia recorrido de carga con " + capacidadCarga + " toneladas.");
    }

    public int getCapacidadDeCarga() {
        return capacidadCarga;
    }

    @Override
    public String toString() {
        return super.toString() + ", Tipo Camion, carga: " + capacidadCarga + " toneladas";
    }
    
    
}
