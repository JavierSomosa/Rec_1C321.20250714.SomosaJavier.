/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestionDeTransporte;

/**
 *
 * @author Javier
 */
public class VehiculoDeInspeccion extends Vehiculo{
    private UsoAsignado UsoAsignado;

    public VehiculoDeInspeccion(UsoAsignado UsoAsignado, String patente, String marca, int anioFabricacion) {
        super(patente, marca, anioFabricacion);
        this.UsoAsignado = UsoAsignado;
    }
    
    @Override
    public void iniciarRecorrido(){
        System.out.println(patente + " es un vehiculo de inspeccion y no va en el recorrido");
    }

    @Override
    public String toString() {
        return super.toString() + " , Tipo Inspeccion, Uso: " + UsoAsignado;
    }
    
    
}
